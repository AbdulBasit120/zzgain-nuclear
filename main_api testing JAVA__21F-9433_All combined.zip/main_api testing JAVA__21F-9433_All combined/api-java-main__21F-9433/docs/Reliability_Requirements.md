# Requirements
- Availability:

The web API will be available 99.99% of the time per day under the maximum load of 10 million concurrent users.
Test: Measure system availability under load and validate against the defined availability percentage.
Fault Tolerance:

The system should continue to operate without a single point of failure, ensuring uninterrupted service even in the event of hardware or software failures.
Test: Conduct fault injection testing to ensure fault tolerance mechanisms are effective.
Recovery Time:

In the event of a failure, the system should recover and resume normal operations within 5 minutes.
Test: Simulate failures and measure the time it takes for the system to recover.
- 
package com.example.crudapi.repository;

import com.example.crudapi.model.Item;

public class ItemRepository {

	public Item save(Item retrievedItem) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object findById(Object id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteById(Object id) {
		// TODO Auto-generated method stub
		
	}

}

/**
 * 
 */
package com.example.crudapi.model;

/**
 * 
 */
public class Item {

	public Object getId() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setName(double d) {
		// TODO Auto-generated method stub
		
	}

	public Object getPrice() {
		// TODO Auto-generated method stub
		return null;
	}

}

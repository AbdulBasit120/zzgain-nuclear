package com.example.crudapi.service;

import java.util.List;

import com.example.crudapi.model.Item;

public class ItemService {

	public List<Item> getAllItems() {
		// TODO Auto-generated method stub
		return null;
	}

	public Item getItemById(Long itemId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Item saveItem(Item newItem) {
		// TODO Auto-generated method stub
		return null;
	}

}

package org.mockito;

public class MockitoAnnotations {

	public static void openMocks(ItemServiceTest itemServiceTest) {
		// TODO Auto-generated method stub
		
	}

}

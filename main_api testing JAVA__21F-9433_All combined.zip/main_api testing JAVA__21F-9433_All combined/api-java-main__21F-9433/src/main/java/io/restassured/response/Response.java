package io.restassured.response;

public class Response {

	public Object getStatusCode() {
		// TODO Auto-generated method stub
		return null;
	}

}

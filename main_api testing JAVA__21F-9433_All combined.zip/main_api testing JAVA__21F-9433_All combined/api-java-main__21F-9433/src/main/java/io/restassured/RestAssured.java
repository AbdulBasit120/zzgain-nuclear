package io.restassured;

public class RestAssured {

	public static String baseURI;

}

import com.example.crudapi.model.Item;
import com.example.crudapi.repository.ItemRepository;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

@SpringBootTest
public class APITesting {

    private static final String BASE_URL = "http://your-api-base-url"; // Update with your actual base URL
    private static final String AUTH_TOKEN = "your-auth-token"; // Update with your actual auth token

    @Autowired
    private ItemRepository itemRepository;

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void testRepositoryOperations() {
        // Test data
        Item newItem = new Item();
        newItem.setName("Test Item");
        newItem.setName(19.99);

        // Save item to the repository
        Item savedItem = itemRepository.save(newItem);

        // Retrieve item from the repository
        Item retrievedItem = ((Object) itemRepository.findById(savedItem.getId())).orElse(null);
        assertEquals(retrievedItem, savedItem);

        // Update the item and save it again
        retrievedItem.setName(29.99);
        Item updatedItem = itemRepository.save(retrievedItem);
        assertEquals(updatedItem.getPrice(), 29.99);

        // Delete the item from the repository
        itemRepository.deleteById(updatedItem.getId());
        Item deletedItem = ((Object) itemRepository.findById(updatedItem.getId())).orElse(null);
        assertEquals(deletedItem, null);
    }

    @Test
    public void testValidSearchApiRequest() {
        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/search?query=Sales");

        assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }

    private Object given() {
		// TODO Auto-generated method stub
		return null;
	}

	@Test
    public void testInvalidSearchApiRequestWithSpecialCharacters() {
        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/search?query=!@#$%");

        assertEquals(400, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testSearchApiRequestWithEmptyKeyword() {
        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/search");

        assertEquals(400, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testValidCustomizeApiRequestWithSettings() {
        // Example JSON payload for customization settings
        String jsonPayload = "{\"chartType\": \"bar\", \"dateRange\": \"last_month\"}";

        Response response = ((Object) given())
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .body(jsonPayload)
            .when()
            .post("/api/customize");

        assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testInvalidCustomizeApiRequestWithConflictingSettings() {
        // Example JSON payload for conflicting customization settings
        String jsonPayload = "{\"chartType\": \"bar\", \"dateRange\": \"5_years\"}";

        Response response = ((Object) given())
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .body(jsonPayload)
            .when()
            .post("/api/customize");

        assertEquals(400, response.getStatusCode());
        // Additional assertions based on your API response
    }
}

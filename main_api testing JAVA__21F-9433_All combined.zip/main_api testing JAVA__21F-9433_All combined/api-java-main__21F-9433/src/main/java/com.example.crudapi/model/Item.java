import com.example.crudapi.model.Item;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

public class APITesting {

    private static final String BASE_URL = "http://your-api-base-url"; // Update with your actual base URL
    private static final String AUTH_TOKEN = "your-auth-token"; // Update with your actual auth token

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void testGetAllItems() {
        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/items");

        assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testGetItemById() {
        // Assuming there is an item with id 1 in your database
        Long itemId = 1L;

        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/items/{id}", itemId);

        assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testSaveItem() {
        Item newItem = new Item();
        newItem.setName("Test Item");
        newItem.setPrice(19.99);

        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .contentType(ContentType.JSON)
            .body(newItem)
            .when()
            .post("/api/items");

        assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testDeleteItem() {
        // Assuming there is an item with id 1 in your database
        Long itemId = 1L;

        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .delete("/api/items/{id}", itemId);

        assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }
}

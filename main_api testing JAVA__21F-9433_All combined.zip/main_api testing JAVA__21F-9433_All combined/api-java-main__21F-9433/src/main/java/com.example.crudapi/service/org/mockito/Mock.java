package org.mockito;

public class Mock {

}

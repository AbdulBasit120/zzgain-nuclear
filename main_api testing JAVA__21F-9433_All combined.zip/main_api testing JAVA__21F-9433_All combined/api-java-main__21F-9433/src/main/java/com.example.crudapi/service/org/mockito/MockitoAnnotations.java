package org.mockito;

public class MockitoAnnotations {

}

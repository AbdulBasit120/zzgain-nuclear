package org.mockito;

public class InjectMocks {

}



import com.example.crudapi.model.Item;
import com.example.crudapi.repository.ItemRepository;
import com.example.crudapi.service.ItemService;
import com.example.crudapi.service.ItemServiceImpl;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertEquals;

@SpringBootTest
public class APITesting {

    private static final String BASE_URL = "http://your-api-base-url";
    private static final String AUTH_TOKEN = "your-auth-token";

    @InjectMocks
    private ItemServiceImpl itemService = new ItemServiceImpl();

    @Mock
    private ItemRepository itemRepository;

    @BeforeClass
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void testRepositoryOperations() {
        // ... (repository tests)
    }

    @Test
    public void testValidSearchApiRequest() {
        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/search?query=Sales");

        assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testInvalidSearchApiRequestWithSpecialCharacters() {
        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/search?query=!@#$%");

        assertEquals(400, response.getStatusCode());
        // Additional assertions based on your API response
    }

    private Object given() {
		// TODO Auto-generated method stub
		return null;
	}

	@Test
    public void testSearchApiRequestWithEmptyKeyword() {
        Response response = ((Object) given())
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/search");

        assertEquals(400, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testValidCustomizeApiRequestWithSettings() {
        String jsonPayload = "{\"chartType\": \"bar\", \"dateRange\": \"last_month\"}";

        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .body(jsonPayload)
            .when()
            .post("/api/customize");

        assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testInvalidCustomizeApiRequestWithConflictingSettings() {
        String jsonPayload = "{\"chartType\": \"bar\", \"dateRange\": \"5_years\"}";

        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .body(jsonPayload)
            .when()
            .post("/api/customize");

        assertEquals(400, response.getStatusCode());
        // Additional assertions based on your API response
    }
}

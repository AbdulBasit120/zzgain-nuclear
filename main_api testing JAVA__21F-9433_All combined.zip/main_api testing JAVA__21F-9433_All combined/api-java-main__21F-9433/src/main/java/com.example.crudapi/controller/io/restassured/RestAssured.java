package io.restassured;

public class RestAssured {

}

package io.restassured.response;

public class Response {

}

package io.restassured.http;

public class ContentType {

}

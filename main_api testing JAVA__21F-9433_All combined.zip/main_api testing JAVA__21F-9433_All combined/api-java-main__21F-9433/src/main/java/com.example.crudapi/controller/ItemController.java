import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.AssertJUnit;
import com.example.crudapi.model.Item;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import org.junit.platform.commons.annotation.Testable;
import org.openqa.selenium.devtools.v116.runtime.Runtime.EvaluateResponse;
import org.testng.annotations.BeforeClass;
import java.net.ResponseCache;
import java.util.HashMap;
import java.util.Map;

import static org.testng.Assert.assertEquals;

public class APITesting {

    private static final String BASE_URL = "http://your-api-base-url"; // Update with your actual base URL
    private static final String AUTH_TOKEN = "your-auth-token"; // Update with your actual auth token

    @BeforeMethod
	@BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void testGetAllItems() {
        org.openqa.selenium.devtools.v117.network.model.Response response = ((Object) given())
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/items");

        AssertJUnit.assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
    public void testGetItemById() {
        // Assuming there is an item with id 1 in your database
        Long itemId = 1L;

        EvaluateResponse response = ((Object) given())
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .get("/api/items/{id}", itemId);

        AssertJUnit.assertEquals(200, ((Object) response).getStatusCode());
        // Additional assertions based on your API response
    }

    @Test
	@Testable
    public void testSaveItem() {
        Item newItem = new Item(/* Set properties for the new item */);

        ResponseCache response = ((Object) given())
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .contentType(ContentType.JSON)
            .body(newItem)
            .when()
            .post("/api/items");

        AssertJUnit.assertEquals(200, ((Object) response).getStatusCode());
        // Additional assertions based on your API response
    }

    private Object given() {
		// TODO Auto-generated method stub
		return null;
	}

	@Test
    public void testDeleteItem() {
        // Assuming there is an item with id 1 in your database
        Long itemId = 1L;

        Response response = given()
            .header("Authorization", "Bearer " + AUTH_TOKEN)
            .when()
            .delete("/api/items/{id}", itemId);

        AssertJUnit.assertEquals(200, response.getStatusCode());
        // Additional assertions based on your API response
    }
}

package com.example.crudapi.model;

public class Item {

}
